// import action types in this file to avoid typos
// + error messages if misconfigured

export const config = {
  manager: [],
  admin: []
};
