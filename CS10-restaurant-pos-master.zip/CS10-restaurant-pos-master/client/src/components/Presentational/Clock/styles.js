import styled from 'styled-components';

export const Clock = styled.h2`
  font-size: 1.7rem;
`;
