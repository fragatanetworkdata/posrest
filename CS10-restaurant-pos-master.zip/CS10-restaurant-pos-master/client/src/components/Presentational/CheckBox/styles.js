import styled from 'styled-components';

import { checkbox } from '../../../global-styles/mixins';

export const CheckBox = styled.div`
  ${checkbox};
  display: flex;
`;
