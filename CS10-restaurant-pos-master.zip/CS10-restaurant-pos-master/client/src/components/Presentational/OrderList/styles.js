import styled from 'styled-components';

export const Scroll = styled.div`
  height: 60%;
  width: 100%;
  overflow-y: scroll;
`;
