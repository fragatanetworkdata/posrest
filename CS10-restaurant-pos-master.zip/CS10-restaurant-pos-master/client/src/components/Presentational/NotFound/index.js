import React, { Component } from 'react';

import * as s from './styles';

class NotFound extends Component {
  render() {
    return <s.Container>404 Not Found</s.Container>;
  }
}

export default NotFound;
