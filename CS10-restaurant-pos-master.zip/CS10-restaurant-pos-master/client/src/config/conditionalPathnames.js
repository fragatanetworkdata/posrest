export const sidebar = [
  '/',
  '/404',
  '/login',
  '/logout',
  '/register',
  '/new-restaurant',
  '/login-employee',
  '/new-employee',
  '/registration-success'
];
